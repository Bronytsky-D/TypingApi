import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AuthService } from '../../core/modules/services/auth.service';
import { Router } from '@angular/router';
import { RecordService } from '../../core/modules/services/record.service';
import { ExecutionResponse } from '../../core/modules/interfaces/execution-response';
import { RecordResponse } from '../../core/modules/interfaces/record-response';
import { DatePipe } from '@angular/common';
import { NeatConfig, NeatGradient } from "@firecms/neat";


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
  providers: [DatePipe]
})
export class ProfileComponent implements OnInit {

  records: RecordResponse[] = [];
  reversedRecords: RecordResponse[]= [];
  userDetail: any = null;
  timeTyping: number = 0;
  wpmPoints: string = '';
  accuracyPoints: string = '';
  maxWpm: number = 100;
  maxAccuracy: number = 100;
  testsStarted: number = 0;
testsCompleted: number = 0;
estimatedWordsTyped: number = 0;
highestWpm: number = 0;
highestAccuracy: number = 0;
highestConsistency: number = 0;

averageRawWpm: number = 0;
averageRawAccuracy: number = 0;
averageRawConsistency: number = 0;
  
  months: string[] = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'Dicember'];
  heatmapData: { [month: string]: number[] } = {};

  constructor(private authService: AuthService, private recordService: RecordService, private router: Router) {
  }

  ngOnInit(): void {
    this.userDetail = this.authService.getUserDetail();

    this.recordService.read(this.authService.getUserDetail()?.id).subscribe(
      (response: ExecutionResponse) => {
        if (response.success) {
          this.records = response.result;
          this.reversedRecords = [...this.records].reverse();
          console.log('Records fetched:', this.records);
          this.calculationTimeTyping();
          this.prepareHeatmapData();
          this.generateGraphs();
          this.processStatistics();
        } else {
          console.error('Error retrieving records', response.message);
        }
      },
      (error: any) => {
        console.error('Error retrieving records', error);
      }
    );
  }

  calculationTimeTyping(): void{
    this.timeTyping = this.records.reduce((sum,record) =>  sum + record.matchTime, 0);
    console.log(this.timeTyping)
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/typing-game']);
  }

  prepareHeatmapData(): void {
    this.months.forEach(month => {
      this.heatmapData[month] = Array(31).fill(0); 
    });

    this.records.forEach(record => {
      const date = new Date(record.dateRecord);
      const month = this.months[date.getMonth()];
      const day = date.getDate() - 1; 
      this.heatmapData[month][day] += 1; 
    });
  } 
  
  initializeHeatmapLevel(val: number): string {
    return val === 1 ? 'level-1' : 
           val === 2 ? 'level-2' : 
           val === 3 ? 'level-3' : 
           val === 4 ? 'level-4' : 
           val >= 5 ? 'level-5' : 
           'level-0';
  }

  formatTime(seconds: number): string {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
  
    return [hours, minutes, remainingSeconds]
      .map(v => v < 10 ? "0" + v : v)
      .filter((v,i) => v !== "00" || i > 0)
      .join(":");
  }

  generateGraphs(): void {
  if (!this.records.length) return;

  const last10 = [...this.records].sort((a, b) => new Date(b.dateRecord).getTime() - new Date(a.dateRecord).getTime()).slice(0, 10).reverse();

  const chartWidth = 600;
  const chartHeight = 200;
  const padding = 20;
  const stepX = (chartWidth - 2 * padding) / (last10.length - 1);
  this.maxWpm = Math.max(...last10.map(r => r.wpm), 1);
  this.maxAccuracy = 100;

  this.wpmPoints = last10.map((r, i) => {
    const x = padding + i * stepX;
    const y = chartHeight - (r.wpm / this.maxWpm) * (chartHeight - padding);
    return `${x},${y}`;
  }).join(' ');

  this.accuracyPoints = last10.map((r, i) => {
    const x = padding + i * stepX;
    const y = chartHeight - (r.accuracy / this.maxAccuracy) * (chartHeight - padding);
    return `${x},${y}`;
  }).join(' ');
}
private processStatistics(): void {
  this.testsStarted = this.records.length;
  this.testsCompleted = this.records.length;
  
 //доробити
 const avgWordLength = 5;
this.estimatedWordsTyped = this.records.reduce(
  (sum, r) => sum + Math.round(r.chars / avgWordLength), 0
);

  this.highestWpm = Math.max(...this.records.map(r => r.wpm));
  this.highestAccuracy = Math.max(...this.records.map(r => r.accuracy));
  this.highestConsistency = Math.max(...this.records.map(r => r.consistency ?? 0));

  this.averageRawWpm = Math.round(
    this.records.reduce((sum, r) => sum + r.raw, 0) / this.records.length
  );

  this.averageRawAccuracy = Math.round(
    this.records.reduce((sum, r) => sum + r.accuracy, 0) / this.records.length
  );

  this.averageRawConsistency = Math.round(
    this.records.reduce((sum, r) => sum + (r.consistency ?? 0), 0) / this.records.length
  );
}
 
}

